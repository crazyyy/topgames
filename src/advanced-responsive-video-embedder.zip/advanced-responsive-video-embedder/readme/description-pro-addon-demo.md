### Pro Addon Feature Demonstration ###

`[[vimeo id="124858722" mode="lazyload" maxwidth="400" align="left"]] This is a demo of a aligned lazyloaded video [...]`

[vimeo id="124858722" mode="lazyload" maxwidth="400" align="left"] This is a demo of a aligned lazyloaded video that has a maximal width set and will grow on click before loading the video.

You can open up a lightbox with a normal link [youtube id="Q6goNzXrmFs" mode="link-lightbox" link_text="click me"] with this sortcode:

`[[youtube id="Q6goNzXrmFs" mode="link-lightbox" link_text="click me"]]`
<div class="clearfix"></div>

We can also center videos and open then inside a Colorbox. This requires the jQuery Colorbox plugin to be installed. This site uses theme 3.

`[[youtube id="Q6goNzXrmFs" mode="lazyload-lightbox" maxwidth="600" align="center"]]`

[youtube id="Q6goNzXrmFs" mode="lazyload-lightbox" maxwidth="600" align="center"]