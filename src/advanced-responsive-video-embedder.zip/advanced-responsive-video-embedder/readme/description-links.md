
* [Overview][1]
* [Quick Introduction][2]
* [Features][3]
* [Additional Features with the Pro Addon][4]
* [Documentation][10]
* [Tests & Examples][11]
* [Github Page][21]

 [1]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/
 [2]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/#quick-introduction
 [3]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/#features
 [4]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/#additional-features-with-the-pro-addon
 [10]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/documentation/
 [11]: https://nextgenthemes.com/plugins/advanced-responsive-video-embedder-pro/tests-and-examples/
 [21]: https://github.com/nextgenthemes/advanced-responsive-video-embedder