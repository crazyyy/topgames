### Experimental Modes ###

The pro version has two experimental modes.

#### Lazyload -> Fullscreen ####

This is sort of a dream come true because to me it never really made sense to watch videos in small boxes in the middle of the page, lightboxes are half way there but why not go straight to fullscreen? You now can. There is a issue though and that is the fact that technically this uses the HTML 5 fullscreen feature on the iframe with the video in it. This means if you click the fullscreen button for HTML 5 videos from the Fullscreen it goes to fullscreen and 2nd time. For HTML 5 Players (tested with YouTube and Vimeo) the result is that users have to push the fullscreen button two times from inside the fullscreen to exit it. Its a matter of your opinion how big the issue is for you. When it comes to flash this sadly gets worse because the fullscreen button will go in the flash fullscreen mode and on exit you are still in the HTML fullscreen mode when done with the mouse. The excape key however works fine for me in Firefox (needs more testing).

[youtube id="WHZPEkZCqwA" mode="lazyload-fullscreen"]
