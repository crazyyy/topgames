### Perfect Drop in Replacement ###

It lets you embed videos from many providers with full responsive sizes via URL or Shortcodes. Let your sites load faster with Lazyload mode (Provider must support native thumbnails). Show videos as thumbnails and let them open in Colorbox. Clean and easy shortcode syntax.

The Plugin has a set of customization options to embed the video exactly as you like, this includes custom URL parameters. Defaults to make the videos as unobtrusive as possible and keep your visitors on your site are already included.

= Perfect drop in replacement for the WordPress easy embeds feature =

If you have [URLs on its own line](https://codex.wordpress.org/Embeds) in your posts/pages this plugin will make them responsive and ads its special features to this embeds right after activation without you having to to anything. If you decide to disable this plugin for any reason, the embeds will still work as before!

This effect the following video hosters WP supports by default: Blip, YouTube, Funny Or Die, Dailymotion, Vimeo, Vine, TED Talks.