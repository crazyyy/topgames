### Roadmap ###

* Support for self-hosted videos.