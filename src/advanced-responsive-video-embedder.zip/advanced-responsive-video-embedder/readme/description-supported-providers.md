### Supported providers ###

* iframe (General support for any provider that not included that support responsive iframe embeds)
* 4players.de
* archive.org
* blip
* break
* CollegeHumor
* Comedy Central
* dailymotion
* flickr
* Funny or Die
* gametrailers
* IGN
* kickstarter
* LiveLeak
* metacafe
* movieweb
* MPORA
* myspace
* MyVideo
* snotr
* spike
* TED Talks
* twitch
* USTREAM
* veoh
* vevo
* viddler
* videojug
* vine
* vimeo
* XTube
* Yahoo Screen
* YouTube