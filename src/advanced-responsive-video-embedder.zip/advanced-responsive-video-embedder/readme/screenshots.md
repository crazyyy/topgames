## Screenshots ##

1. In action
2. Options page