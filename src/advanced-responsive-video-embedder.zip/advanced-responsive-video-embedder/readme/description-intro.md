### The best WordPress plugin for videos? Supports close to everything you can imagine, still keeping it easy &amp; simple. ###

This is very likely the one and only plugin you will ever need to handle video embeds on your WordPress site(s)

Simple &bull; Lightweight &bull; Responsive &bull; Customizable

Please check the [migration guide](https://nextgenthemes.com/?p=1875) after updating to version 6.0.0+.

Please report issues on [community.nextgenthemes.com](https://community.nextgenthemes.com/) **and not on the wordpress.org forums.**